from langchain_core.embeddings import Embeddings

# This is for backwards compatibility
__all__ = ["Embeddings"]
